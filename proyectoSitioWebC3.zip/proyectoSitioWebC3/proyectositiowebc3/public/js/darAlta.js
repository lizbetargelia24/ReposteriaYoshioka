// Import the functions you need from the SDKs you need
import { initializeApp } from "https://www.gstatic.com/firebasejs/9.13.0/firebase-app.js";
import{ getDatabase,onValue, ref, set, child, get, update, remove }
from "https://www.gstatic.com/firebasejs/9.13.0/firebase-database.js";
import{getStorage,ref as refS, uploadBytes, getDownloadURL} 
from "https://www.gstatic.com/firebasejs/9.13.0/firebase-storage.js";
// TODO: Add SDKs for Firebase products that you want to use
// https://firebase.google.com/docs/web/setup#available-libraries

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyC6Ppdc826ZAE4fNV6mpmRDp3ixgXa45ps",
  authDomain: "pagweb3-8ebd2.firebaseapp.com",
  projectId: "pagweb3-8ebd2",
  storageBucket: "pagweb3-8ebd2.appspot.com",
  messagingSenderId: "59890602224",
  appId: "1:59890602224:web:e991c7d06afcb802e7b235"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getDatabase();

//declaracion de objetos
var archivo = document.getElementById('archivo');
var btnVerImagen = document.getElementById('btnVerImagen');
var btnLimpiar = document.getElementById('btnLimpiar');
var  inputCodigo ="";
var  inputNombreProducto ="";
var  inputDescripcion ="";
var  inputPrecio ="";
var  inputEstado ="";
var imgNombre = "";
var  inputUrl ="";



// Botón insertar
document.getElementById("btnInsertar").addEventListener("click", () => {
  var inputCodigo = document.getElementById("codigo").value;
  var inputNombreProducto = document.getElementById("nombre").value;
  var inputDescripcion = document.getElementById("descrip").value;
  var inputPrecio = document.getElementById("precio").value;
  var inputEstado = document.getElementById("status").value;
  var inputUrl = document.getElementById("url").value;
  var imgNombre = document.getElementById("imgNombre").value;

  fetch("http://localhost:3004/insertar", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
    },
    body: JSON.stringify({
      codigo: inputCodigo,
      nombreProducto: inputNombreProducto,
      descripcion: inputDescripcion,
      precio: inputPrecio,
      estado: inputEstado,
      imgNombre: imgNombre,
      url: inputUrl,
    }),
  })
    .then((res) => res.json())
    .then((res) => {
      window.alert("Producto insertado con éxito");
      console.log(res);
    });
});


// Botón para mostrar Todo
var inputEstado = document.getElementById('status').value;
document.getElementById('btnTodos').addEventListener('click', event => {
event.preventDefault();
fetch('http://localhost:3004/mostrarTodos', {
  method: 'GET',
  headers: {
      "Content-Type": "application/json",
  },
})
.then(res => res.json())
.then(res => {
  const tabla = document.querySelector('#tablaDatos tbody');
  tabla.innerHTML = ''; // Vacía la tabla antes de agregar nuevos datos
  res.forEach(dato => {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td>${dato.id}</td>
        <td>${dato.codigo}</td>
        <td>${dato.nombreProducto}</td>
        <td>${dato.descripcion}</td> 
        <td>${dato.precio}</td>
        <td>${dato.estado}</td>
      `;
      tabla.appendChild(fila);
      
  });
});
});

// Botón para buscar por código
document.getElementById('btnBuscar').addEventListener('click', event => {
event.preventDefault();
const codigo = document.getElementById('codigo').value;
console.log(codigo)
fetch(`http://localhost:3004/buscarCodigo?codigo=${codigo}`, {
method: 'GET',
headers: {
"Content-Type": "application/json",
}
})
.then(res => res.json())
.then(res => {
const tabla = document.querySelector('#tablaDatos tbody');
  tabla.innerHTML = ''; // Vacía la tabla antes de agregar nuevos datos
  res.forEach(dato => {
      const fila = document.createElement('tr');
      fila.innerHTML = `
        <td>${dato.id}</td>
        <td>${dato.codigo}</td>
        <td>${dato.nombreProducto}</td>
        <td>${dato.descripcion}</td>
        <td>${dato.precio}</td>
        <td>${dato.estado}</td>
      `;
      tabla.appendChild(fila);
      
      document.getElementById('nombre').value = dato.nombreProducto;
      document.getElementById('descrip').value = dato.descripcion;
      document.getElementById('precio').value = dato.precio;
      document.getElementById('status').value = dato.estado;
      document.getElementById('imgNombre').value = dato.imgNombre;
      document.getElementById('url').value = dato.url;
      //document.getElementById('status').value = dato.inputEstado;

  });  



}
);
});

function escribirInputs(){
  document.getElementById('codigo').value = inputCodigo;
  document.getElementById('nombre').value = inputNombreProducto;
  document.getElementById('descrip').value = inputDescripcion;
  document.getElementById('precio').value = inputPrecio;
  document.getElementById('imgNombre').value = imgNombre;
  document.getElementById('url').value = inputUrl;
  document.getElementById('status').value = inputEstado;
}

//Botón para borrar por código
// document.getElementById('btnBorrar').addEventListener('click', event => {
// event.preventDefault();
// const codigo = document.getElementById('codigo').value;
// console.log(codigo)
// fetch(`http://localhost:3004/borrarPorCodigo?codigo=${codigo}`, {
// method: 'DELETE',
// headers: {
// "Content-Type": "application/json"
// }
// })
// .then(res => res.json())
// .then(res => {
// // Mostrar mensaje de éxito o error
// console.log(res);
// });
// });

document.getElementById('btnBorrar').addEventListener('click', event => {
  event.preventDefault();
  
  var inputCodigo = document.getElementById('codigo').value;
  var inputNombreProducto = document.getElementById('nombre').value;
  var inputDescripcion = document.getElementById('descrip').value;
  var inputPrecio = document.getElementById('precio').value;
  var inputEstado = document.getElementById('status').value;
  var imgNombre = document.getElementById('imgNombre').value;
  var inputUrl = document.getElementById('url').value;
      
  fetch(`http://localhost:3004/borrarPorCodigo?codigo=${inputCodigo}`, {
  method: 'PUT',
  headers: {
  "Content-Type": "application/json"
  },
  body: JSON.stringify({
        
    codigo: inputCodigo,
    nombreProducto: inputNombreProducto, 
    descripcion: inputDescripcion,
    precio: inputPrecio,
    estado: inputEstado,
    imgNombre: imgNombre,
    url: inputUrl
        
  })
  })
  .then(res => res.json())
  .then(res => {
  // Mostrar mensaje de éxito o error
  window.alert("Producto deshabilitado con éxito")
  console.log(res);
  });
  });




//Botón para actualizar
document.getElementById('btnActualizar').addEventListener('click', event => {
event.preventDefault();

  var inputCodigo = document.getElementById('codigo').value;
  var inputNombreProducto = document.getElementById('nombre').value;
  var inputDescripcion = document.getElementById('descrip').value;
  var inputPrecio = document.getElementById('precio').value;
  var inputEstado = document.getElementById('status').value;
  var imgNombre = document.getElementById('imgNombre').value;
  var inputUrl = document.getElementById('url').value;

fetch(`http://localhost:3004/actualizar?codigo=${inputCodigo}`, {
method: 'PUT',
headers: {
"Content-Type": "application/json"
},
body: JSON.stringify({
      codigo: inputCodigo,
      nombreProducto: inputNombreProducto, 
      descripcion: inputDescripcion,
      precio: inputPrecio,
      estado: inputEstado,
      imgNombre: imgNombre,
      url: inputUrl
})
})
.then(res => res.json())
.then(res => {
// Mostrar mensaje de éxito o error
window.alert("Producto actualizado con éxito")
console.log(res);
});
});

function cargarImagen(){
  const file = event.target.files[0];
  const name = event.target.files[0].name;

  const storage = getStorage();
  const storageRef = refS(storage, 'imagenes/' + name);

  //'file' comes from the blob or file API
  uploadBytes(storageRef,file).then((snapshot)=>{
    document.getElementById('imgNombre').value = name;
    alert('Se cargo el archivo');
  });
}

function descargarImagen(){
  archivo = document.getElementById('imgNombre').value;
  // Create a reference to the file we want to download
const storage = getStorage();
const storageRef = refS(storage, 'imagenes/' + archivo);

// Get the download URL
getDownloadURL(storageRef)
  .then((url) => {
    document.getElementById('url').value = url;
    document.getElementById('imagen').src=url;
    // Insert url into an <img> tag to "download"
  })
  .catch((error) => {
    // A full list of error codes is available at
    // https://firebase.google.com/docs/storage/web/handle-errors
    switch (error.code) {
      case 'storage/object-not-found':
        console.log("No existe el archivo")
        // File doesn't exist
        break;
      case 'storage/unauthorized':
        console.log("No tiene permisos")
        // User doesn't have permission to access the object
        break;
      case 'storage/canceled':
        console.log("Se cancelo o no tiene internet")
        // User canceled the upload
        break;

      // ...

      case 'storage/unknown':
        console.log("No sabemos que paso")
        // Unknown error occurred, inspect the server response
        break;
    }
  });
}

function limpiar(){


  inputCodigo ="";
  inputNombreProducto ="";
  inputDescripcion ="";
  inputPrecio ="";
  imgNombre = "";
  inputEstado ="";
  inputUrl ="";
  
    escribirInputs();
  }

archivo.addEventListener('change', cargarImagen);
btnVerImagen.addEventListener('click', descargarImagen);
btnLimpiar.addEventListener('click', limpiar);
