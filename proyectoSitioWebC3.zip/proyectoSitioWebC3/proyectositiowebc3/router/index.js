const express = require("express");
const router = express.Router();
const bodyParse = require("body-parser");
const db = require("../models/productos.js");
const { name } = require("ejs");

router.get("/principal", (req, res) => {
  res.render("principal.html");
});
router.get("/administrador", (req, res) => {
  res.render("administrador.html");
});

router.get("/pedidos", (req, res) => {
  res.render("pedidos.html");
});

router.get("/productos", (req, res) => {
  const login = {
    login:false
  } 
  res.render("productos.html", login);
});

router.get("/ventas", (req, res) => {
  res.render("ventas.html");
});

// router.get("/login", (req, res) => {
//   res.render("login.html");
// });

router.get("/sobreNosotros", (req, res) => {
  res.render("sobreNosotros.html");
});

// router.get("/registro", (req, res) => {
//   res.render("Registro.html");
// });

router.get('/login',(req, res)=>{
  res.render('login');
})

router.get('/register',(req, res)=>{
  res.render('register');
})


// Método para insertar productos en la BD
router.post("/insertar", async (req, res) => {
  producto = {
    codigo: req.body.codigo,
    nombreProducto: req.body.nombreProducto,
    descripcion: req.body.descripcion,
    precio: req.body.precio,
    estado: req.body.estado,
    imgNombre: req.body.imgNombre,
    url: req.body.url,
  };
  let resultado = await db.insertar(producto);
  res.json(resultado);
});

router.post("/ventaAdmin", async (req, res) => {
  venta = {
    nombreProducto: req.body.nombreProducto,
    usuarioCorreo: req.body.usuarioCorreo,
    cantidad: req.body.cantidad,
    precioIndividual: req.body.precioIndividual,
    precioTotal: req.body.precioTotal,
    tipoPago: req.body.tipoPago
  };
  let resultado = await db.insertarVenta(venta);
  res.json(resultado);
});

router.get("/ventaAdmin", async (req, res) => {
  res.render("principal.html")
});


// Método para mostrar todo
router.get("/mostrarTodos", async (req, res) => {
  resultado = await db.mostrarTodos();
  res.json(resultado);
});

router.get("/MostrarVenta", async (req, res) => {
  resultado = await db.mostrarVentas();
  res.json(resultado);
});

router.get("/mostrarTodosUsuarios", async (req, res) => {
  resultado = await db.mostrarTodosUsuarios();
  res.json(resultado);
});


// Método para buscar por id
router.get('/buscarCodigo', (req, res) =>{
    const codigo = req.query.codigo;
    db.buscarCodigo(codigo)
        .then((data) => res.json(data))
        .catch((err) => res.status(404).send(err.message))
  
  })

  router.get('/buscarEstado', (req, res) =>{
    const estado = req.query.estado;
    db.buscarEstado(estado)
        .then((data) => res.json(data))
        .catch((err) => res.status(404).send(err.message))
  })

// Borrar matricula
// router.put("/borrarPorCodigo", (req, res) => {
//   const codigo = req.query.codigo;
//   db.borrarPorCodigo(codigo)
//     .then((data) => res.json(data))
//     .catch((err) => res.status(404).send(err.message));
// });

router.put("/borrarPorCodigo", (req, res) => {
  const productos = req.body;
  db.borrarPorCodigo(productos)
    .then((data) => res.json(data))
    .catch((err) => res.status(404).send(err.message));
});



// Actualizar por codigo
router.put("/actualizar", async(req, res)=>{
    const productos = req.body;
    db.actualizar(productos)
        .then((data) => res.json(data))
        .catch((err) => res.status(404).send(err.message))
  })
    
module.exports=router;