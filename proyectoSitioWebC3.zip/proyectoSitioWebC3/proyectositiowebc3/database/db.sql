create database if not exists sitioWeb;
use sitioWeb;


create table if not exists users(
id int primary key auto_increment,
user varchar(50),
name varchar(50),
pass varchar(255),
domicilio varchar(50),
telefono varchar(50),
correo varchar(50)
);

create table if not exists productos(
id int primary key auto_increment,
codigo int,
nombreProducto varchar(20),
descripcion varchar(25),
cantidad INT DEFAULT 1,
precio float(10),
estado varchar(45),
imgNombre varchar(20),
url varchar(200)
);

create table if not exists ventas(
    id int primary key auto_increment,
    usuarioCorreo varchar(40),
    nombreProducto varchar(20),
    cantidad varchar(150),
    precioIndividual float(11),
    precioTotal float(10),
    tipoPago varchar(50)
);

-- drop table if exists ventas;
select * from ventas;
select correo from users where id = 1;