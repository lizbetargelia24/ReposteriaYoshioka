function enviarCorreo() {
    var nombre = document.getElementById("nombre").value;
    var correo = document.getElementById("correo").value;
    var comentarios = document.getElementById("comentarios").value;
  
  
    var destinatario = "2020030312@upsin.edu.mx";
    var asunto = "Nuevo mensaje";
    var cuerpo = "Nombre: " + nombre + "\n" +
                 "Correo: " + correo + "\n" +
                 "Comentarios: " + comentarios;
  
    var mailtoLink = "mailto:" + destinatario + "?subject=" + encodeURIComponent(asunto) + "&body=" + encodeURIComponent(cuerpo);
  
    if (nombre == "") {
      alert("Debe llenar el campo de 'Nombre'");
    }else if(correo == ""){
      alert("Debe llenar el campo de 'Correo'");
    }else if(comentarios == ""){
      alert("Debe escribir su opinión... Recuerde, mínimo 10 palabras para que sea tomado en cuenta")
    }
    else{
          window.location.href = mailtoLink;
    }
  
    
  }
  
  
  function contarPalabras() {
      var textarea = document.getElementById("comentarios");
      var contador = document.getElementById("contadorPalabras");
      var palabras = textarea.value.trim().split(/\s+/);
      var numPalabras = palabras.length;
    
      contador.textContent = numPalabras + " palabras";
    
      // Cambia 10 por el número mínimo de palabras que deseas
      if (numPalabras < 10) {
        contador.style.color = "white";
        contador.textContent += " (mínimo 10 palabras)";
      } else {
        contador.style.color = "initial";
      }
    }