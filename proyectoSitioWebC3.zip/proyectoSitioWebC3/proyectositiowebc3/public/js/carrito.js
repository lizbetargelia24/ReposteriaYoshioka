//const contenedor = document.getElementById('contenedor-productos')

const contenedorCarrito = document.getElementById("carrito-contenedor");
//SEXTO PASO
const botonVaciar = document.getElementById("vaciar-carrito");
//SEXTIMO PASO, MODIFICAR LOS CONTADORES
const contadorCarrito = document.getElementById("contadorCarrito");

//OCTAVO PASO
const cantidad = document.getElementById("cantidad");
const precioTotal = document.getElementById("precioTotal");
const cantidadTotal = document.getElementById("cantidadTotal");

let carrito = [];
var precioT = 0;

document.addEventListener('DOMContentLoaded', () => {
  
  if (localStorage.getItem('carrito')){
      carrito = JSON.parse(localStorage.getItem('carrito'))
      actualizarCarrito()
  }
})

if (window.location.href == "http://localhost:3004/productos" || window.location.href ==  "http://localhost:3004/")
  [(window.onload = MostrarProductos())];
  
function MostrarProductos() {
  const estado = 0;

  fetch(`http://localhost:3004/buscarEstado?estado=${estado}`, {
    method: "GET",
    headers: {
      "Content-Type": "application/json",
    },
  })
    .then((res) => res.json())
    .then((res) => {
    
      const contenedor = document.getElementById("tabla-pequena");
      contenedor.innerHTML = ""; // Vacía el contenedor antes de agregar nuevas tarjetas
      res.forEach((dato) => {
        const tarjeta = document.createElement("div");
        tarjeta.className = "card mb-3";
        tarjeta.innerHTML = `
        
          <div class="card-header">
            <h3 class="card-title">${dato.nombreProducto}</h3>
          </div>
          <div class="card-body">
            <p class="card-text"><b>Código: </b> ${dato.codigo}</p>
            <p class="card-text"><b>Descripción: </b>${dato.descripcion}</p>
            <p class="card-text"><b>Precio: </b>$${dato.precio}</p>
            <img id='imgCarta' src="${dato.url}" style="max-width: 35%; height: auto;"> <br> <br>
            <button class='btnAgregar' id="agregar${dato.codigo}" class="boton-agregar">Agregar <i class="fas fa-shopping-cart"></i></button>            
          </div>
          
        `;
        contenedor.appendChild(tarjeta);
        const boton = document.getElementById(`agregar${dato.codigo}`);

        boton.addEventListener("click", () => {
          window.alert("Agregaste un " + dato.nombreProducto  + " al carrito")
          //console.log("Se insertó en el carrito el producto con código " + dato.codigo)
          agregarAlCarrito(dato.codigo);
        });
        
        
      });

      
      botonVaciar.addEventListener("click", () => {
        carrito.length = 0;
        actualizarCarrito();
      })
      
      const agregarAlCarrito = (codigo) => {
        console.log(codigo);
        //PARA AUMENTAR LA CANTIDAD Y QUE NO SE REPITA
        const existe = carrito.some((dato) => dato.codigo === codigo); //comprobar si el elemento ya existe en el carro
        // Da falso
        
        if (existe) {
          
          //SI YA ESTÁ EN EL CARRITO, ACTUALIZAMOS LA CANTIDAD
          const dato = carrito.map((dato) => {
            //creamos un nuevo arreglo e iteramos sobre cada curso y cuando
            // map encuentre cual es el q igual al que está agregado, le suma la cantidad
            if (dato.codigo === codigo) {
              dato.cantidad++;
            }
          });
        } else {
          //EN CASO DE QUE NO ESTÉ, AGREGAMOS EL CURSO AL CARRITO
          const item = res.find((dato) => dato.codigo === codigo); //Trabajamos con las ID
          //Una vez obtenida la ID, lo que haremos es hacerle un push para agregarlo al carrito
          carrito.push(item);
        }
        //Va a buscar el item, agregarlo al carrito y llama a la funcion actualizarCarrito, que recorre
        //el carrito y se ve.
        actualizarCarrito(); //LLAMAMOS A LA FUNCION QUE CREAMOS EN EL TERCER PASO. CADA VEZ Q SE
        //MODIFICA EL CARRITO
      };
      
      
      

      
      // Mostrar para el apartado de productos
    });
    
}

const eliminarDelCarrito = (codigo) => {
  const item = carrito.find((dato) => dato.codigo === codigo);

  const indice = carrito.indexOf(item); //Busca el elemento q yo le pase y nos devuelve su indice.

  carrito.splice(indice, 1); //Le pasamos el indice de mi elemento ITEM y borramos
  // un elemento
  
  actualizarCarrito(); //LLAMAMOS A LA FUNCION QUE CREAMOS EN EL TERCER PASO. CADA VEZ Q SE
  //MODIFICA EL CARRITO
  console.log(carrito);
};



const actualizarCarrito = () => {
  //4- CUARTO PASO
  //LOS APPENDS SE VAN ACUMULANDO CON LO QE HABIA ANTES
  contenedorCarrito.innerHTML = ""; //Cada vez que yo llame a actualizarCarrito, lo primero q hago
  //es borrar el nodo. Y despues recorro el array lo actualizo de nuevo y lo rellena con la info
  //actualizado
  //3 - TERCER PASO. AGREGAR AL MODAL. Recorremos sobre el array de carrito.

  //Por cada producto creamos un div con esta estructura y le hacemos un append al contenedorCarrito (el modal)
  carrito.forEach((dato) => {
    const div = document.createElement("div");
    div.className = "productoEnCarrito";
    div.innerHTML = `
    <p><b>${dato.nombreProducto}</b></p>
    <p>Precio: $${dato.precio}</p><br><br><br>
    <p>Cantidad: <span id="cantidad">${dato.cantidad}</span></p>
    <img src="${dato.url}" style="max-width: 150px; height: 100px;">
    <button id="btnEliminarCarrito${dato.codigo}" class="boton-eliminar"><i class="fas fa-trash-alt"></i></button><br><br><br>
    `;        

    

    contenedorCarrito.appendChild(div)

    

    const btnEliminarCarrito = document.getElementById(`btnEliminarCarrito${dato.codigo}`);

    btnEliminarCarrito.addEventListener('click', ()=>{
      eliminarDelCarrito(dato.codigo)
    })

    
  
  })

    
  //SEPTIMO PASO
  contadorCarrito.innerText = carrito.length; // actualizamos con la longitud del carrito.
  //OCTAVO PASO
  console.log(carrito);
  precioTotal.innerText = carrito.reduce(
    (acc, dato) => acc + dato.cantidad * dato.precio, 0
  )
  precioT = carrito.reduce(
    (acc, dato) => acc + dato.cantidad * dato.precio, 0
  )
  localStorage.setItem('carrito', JSON.stringify(carrito))
  //Por cada producto q recorro en mi carrito, al acumulador le suma la propiedad precio, con el acumulador
  //empezando en 0.
}

document.getElementById("btnVenta").addEventListener("click", () => {
  // var inputCodigo = document.getElementById("codigo").value;
  // var inputNombreProducto = document.getElementById("nombre").value;
  // var inputDescripcion = document.getElementById("descrip").value;
  // var inputPrecio = document.getElementById("precio").value;
  // var inputEstado = document.getElementById("status").value;
  // var inputUrl = document.getElementById("url").value;
  // var imgNombre = document.getElementById("imgNombre").value;
  
  var user = document.getElementById('usuario').value;
  var tipodePago = document.getElementById('tipoPago').value;
  console.log(user)
  
   
  if(tipodePago == 0){
    window.alert("Debe seleccionar un método de pago");
  }
  else if(user == 0){
    window.alert("No estás logueado, para compra, debes iniciar sesión")
  }
  
  else{
    
    for (let i = 0; i < carrito.length; i++) {
    
    var codigo = carrito[i].codigo;
    var nombre = carrito[i].nombreProducto;
    var Cantidad = carrito[i].cantidad;
    var precio = carrito[i].precio;
    
    

    fetch("http://localhost:3004/ventaAdmin", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        usuarioCorreo: user,
        nombreProducto: nombre,
        cantidad: Cantidad,
        precioIndividual: precio,
        precioTotal: Cantidad * precio,
        tipoPago: tipodePago
      }),
    })
      .then((res) => res.json())
      .then((res) => {
        window.alert("Se realizó la compra con exito");
        eliminarDelCarrito(codigo)
        console.log("El codigo que se debe eliminar es: " + codigo)
        console.log(res);
        
      });
    }
    }
  });

//contenedorCarrito
// nombre = carrito[1].nombreProducto
// Cantidad = carrito[0].cantidad
// console.log(precioT)
// console.log(nombre)
// console.log(Cantidad)
