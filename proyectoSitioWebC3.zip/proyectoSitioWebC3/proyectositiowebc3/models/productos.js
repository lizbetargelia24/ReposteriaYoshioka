const json = require("express/lib/response");
const promise = require("../models/conexion.js");
const conexion = require("../models/conexion.js");

var productos = {};

// Consulta para insertar
productos.insertar = function insertar(producto) {
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Insert into productos set ?";
    conexion.query(sqlConsulta, producto, function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        resolve({
          id: res.insertId,
          codigo: producto.codigo,
          nombreProducto: producto.nombreProducto,
          descripcion: producto.descripcion,
          precio: producto.precio,
          estado: producto.estado,
          imgNombre: producto.imgNombre,
          url: producto.url,
        });
      }
    });
  });
};

// Consulta para mostrar todos los productos
productos.mostrarTodos = function mostrarTodos() {
  productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Select * from productos";
    conexion.query(sqlConsulta, null, function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        alumno = res;
        resolve(alumno);
      }
    });
  });
};


productos.mostrarTodosUsuarios = function mostrarTodosUsuarios() {
  productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Select * from users";
    conexion.query(sqlConsulta, null, function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        alumno = res;
        resolve(alumno);
      }
    });
  });
}


productos.mostrarVentas = function mostrarVentas() {
  productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Select * from ventas";
    conexion.query(sqlConsulta, null, function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        alumno = res;
        resolve(alumno);
      }
    });
  });
};

// Consulta para buscar por código
productos.buscarCodigo = function buscarCodigo(codigo) {
  productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Select * from productos WHERE codigo = ?";
    conexion.query(sqlConsulta, [codigo], function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        productos = res;
        resolve(res);
      }
    });
  });
};

productos.buscarEstado = function buscarEstado(estado) {
  productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Select * from productos WHERE estado = ?";
    conexion.query(sqlConsulta, [estado], function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        productos = res;
        resolve(res);
      }
    });
  });
};



productos.insertarVenta = function insertarVenta(venta){
  return new Promise((resolve, reject) => {
    var sqlConsulta = "Insert into ventas set ?";
    conexion.query(sqlConsulta, venta, function (err, res) {
      if (err) {
        reject(err.message);
      } else {
        resolve({
          id: res.insertId,
          usuarioCorreo: venta.usuarioCorreo,
          nombreProducto: venta.nombreProducto,
          precioIndividual: venta.precioIndividual,
          cantidad: venta.cantidad,
          precioTotal: venta.precioTotal,
          tipoPago: venta.tipoPago
        });
      }
    });
  });
}

/* Borrar por código */

productos.borrarPorCodigo = function borrarPorCodigo(productos) {
  //productos = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "UPDATE productos SET nombreProducto = ?, descripcion = ?, precio = ?, estado = ?, imgNombre = ?, url = ? WHERE codigo = ?";
    conexion.query(sqlConsulta, [productos.nombreProducto,
      productos.descripcion,
      productos.precio,
      productos.estado = "1",
      productos.imgNombre,
      productos.url,
      productos.codigo,], function (err, res) {
      if (err) {
        reject(err.message);
     } else {
        console.log(res.affectedRows);
       resolve(res.affectedRows);
     }
  });
 });
};

/* Actualizar alumnos por ódigo */
productos.actualizar = function actualizar(productos) {
  //alumno = {};
  return new Promise((resolve, reject) => {
    var sqlConsulta = "UPDATE productos SET nombreProducto = ?, descripcion = ?, precio = ?, estado = ?, imgNombre = ?, url = ? WHERE codigo = ?";
    conexion.query(sqlConsulta,
      [
        productos.nombreProducto,
        productos.descripcion,
        productos.precio,
        productos.estado,
        productos.imgNombre,
        productos.url,
        productos.codigo,
      ],
      function (err, res) {
        if (err) {
          reject(err.message);
          console.log("Error");
        } else {
          resolve(res.affectedRows);
        }
      }
    );
  });
};

module.exports = productos;
