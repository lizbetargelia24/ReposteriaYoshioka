const http = require('http');
const express = require('express');
const app = express();
// const bodyparser = require("body-parser");
const misrutas = require('./router/index');
const path = require('path');



app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

// app.use(bodyparser.urlencoded({extended:true}));
app.use(express.urlencoded({extended:false}));
app.use(express.json());
app.use(misrutas);

//3- Invocamos a dotenv
const dotenv = require('dotenv');
dotenv.config({ path: './env/.env'});



//4 -seteamos el directorio de assets
app.use('/resources',express.static('public'));
app.use('/resources', express.static(__dirname + '/public'));

app.engine('html',require('ejs').renderFile);

//5 - Establecemos el motor de plantillas
app.set('view engine','ejs');

//6 -Invocamos a bcrypt
const bcrypt = require('bcryptjs');

//7- variables de session
const session = require('express-session');
app.use(session({
	secret: 'secret',
	resave: true,
	saveUninitialized: true
}));
console.log(session)


// 8 - Invocamos a la conexion de la DB
const sqlConnection = require('./models/conexion');

//9 - establecemos las rutas
app.get('/login',(req, res)=>{
    res.render('login');
})

app.get('/register',(req, res)=>{
    res.render('register');
})

//10 - Método para la REGISTRACIÓN
app.post('/register', async (req, res)=>{
	const user = req.body.user;
	const name = req.body.name;
    //const rol = req.body.rol;
	const pass = req.body.pass;
	const domicilio = req.body.domicilio;
	const telefono = req.body.telefono;
	const correo = req.body.correo;
	let passwordHash = await bcrypt.hash(pass, 8);
    sqlConnection.query('INSERT INTO users SET ?',{user:user, name:name, pass:passwordHash, domicilio:domicilio, telefono: telefono, correo:correo}, async (error, results)=>{
        if(error){
            console.log(error);
        }else{            
			res.render('register', {
				alert: true,
				alertTitle: "Registration",
				alertMessage: "¡Successful Registration!",
				alertIcon:'success',
				showConfirmButton: false,
				timer: 1500,
				ruta: 'login'
			});
			 // Almacenar user y name en Local Storage
			 
            //res.redirect('/');         
        }
	});
})




//11 - Metodo para la autenticacion
app.post('/auth', async (req, res)=> {
	const user = req.body.user;
	const pass = req.body.pass;    
    let passwordHash = await bcrypt.hash(pass, 8);
	if (user && pass) {
		
		sqlConnection.query('SELECT * FROM users WHERE user = ?', [user], async (error, results, fields)=> {
			if( results.length == 0 || !(await bcrypt.compare(pass, results[0].pass)) ) {    
				res.render('login', {
                        alert: true,
                        alertTitle: "Error",
                        alertMessage: "USUARIO y/o PASSWORD incorrectas",
                        alertIcon:'error',
                        showConfirmButton: true,
                        timer: false,
                        ruta: ''    
                    });
				
				//Mensaje simple y poco vistoso
                //res.send('Incorrect Username and/or Password!');				
			}else if(user == "UsuarioMaestro" && pass == "1234"){
				req.session.loggedin = true;                
				req.session.name = results[0].name;
				
				res.render('login', {
					alert: true,
					alertTitle: "Conexión exitosa",
					alertMessage: "¡LOGIN CORRECTO!",
					alertIcon:'success',
					showConfirmButton: false,
					timer: 1500,
					ruta: 'administrador'
					
				});  
			}
			else {         
				//creamos una var de session y le asignamos true si INICIO SESSION       
				req.session.loggedin = true;                
				req.session.name = results[0].name;
				req.session.user = results[0].user;
				res.render('login', {
					alert: true,
					alertTitle: "Conexión exitosa",
					alertMessage: "¡LOGIN CORRECTO!",
					alertIcon:'success',
					showConfirmButton: false,
					timer: 1500,
					ruta: ''
				});        	
				
			 		
			}	
			
			res.end();
		});
	} else {	
		res.send('Please enter user and Password!');
		res.end();
	}
});

//12 - Método para controlar que está auth en todas las páginas
app.get('/', (req, res)=> {
	if (req.session.loggedin) {
		res.render('productos.html',{
			login: true,
			name: req.session.user	
		});		
	} else {
		res.render('login',{
			login: false,
			name:'Debe iniciar sesión',			
		});				
	}
	res.end();
});


//función para limpiar la caché luego del logout
app.use(function(req, res, next) {
    if (!req.user)
        res.header('Cache-Control', 'private, no-cache, no-store, must-revalidate');
    next();
});

 //Logout
//Destruye la sesión.
app.get('/logout', function (req, res) {
	req.session.destroy(() => {
	
	  res.redirect('/') // siempre se ejecutará después de que se destruya la sesión
	})
});



app.use((req,res,next)=>{
    res.status(404).sendFile(__dirname + '/public/error.html')
});

//  escuchar el servidor por el puerto 3004
const puerto = 3004;
app.listen(puerto,() => {
    
    console.log("iniciado en el puerto 3004");


});