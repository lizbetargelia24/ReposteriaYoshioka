// Botón para mostrar Todos los usuarios registrados

document.getElementById('btnMostrarUsuarios').addEventListener('click', event => {
    event.preventDefault();
    fetch('http://localhost:3004/mostrarTodosUsuarios', {
      method: 'GET',
      headers: {
          "Content-Type": "application/json",
      },
    })
    .then(res => res.json())
    .then(res => {
      const tabla = document.querySelector('#tablaUsuarios tbody');
      tabla.innerHTML = ''; // Vacía la tabla antes de agregar nuevos datos
      res.forEach(dato => {
          const fila = document.createElement('tr');
          fila.innerHTML = `
            <td>${dato.id}</td>
            <td>${dato.user}</td>
            <td>${dato.name}</td>
            <td>${dato.domicilio}</td> 
            <td>${dato.telefono}</td>
            <td>${dato.correo}</td>
          `;
          tabla.appendChild(fila);
          
      });
    });
    });
    